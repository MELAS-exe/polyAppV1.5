import 'package:flutter/material.dart';
import 'package:polyapp/util/constante.dart';

class BoutiqueItems extends StatelessWidget {
  final String title;
  final double price;
  Image? image;

  BoutiqueItems({super.key, required this.title, required this.price, this.image});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(5),
          width: 170,
          height: 190,
          decoration: BoxDecoration(
              color: eptLightGrey, borderRadius: BorderRadius.circular(15)),
          child: Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(15)),
            clipBehavior: Clip.hardEdge,
            child: image == null
                ? Center(child: Image.asset("assets/market/no-image.png"))
                : image!,
          ),
        ),
        const SizedBox(
          height: 5,
        ),
        Text(
          title,
          style: const TextStyle(
              fontFamily: "Inter", fontSize: 14, color: eptDarkGrey),
        ),
        const SizedBox(
          height: 5,
        ),
        Text(
          "$price Fcfa",
          style: const TextStyle(
            fontFamily: "Inter",
            fontSize: 16,
          ),
        ),
      ],
    );
  }
}
