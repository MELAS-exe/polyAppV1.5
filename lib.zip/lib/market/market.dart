import 'package:flutter/material.dart';
import 'package:polyapp/market/boutique_wrap.dart';
import 'package:polyapp/market/collection.dart';
import 'package:polyapp/util/constante.dart';
import 'package:polyapp/util/ept_button.dart';

class Market extends StatefulWidget {
  const Market({super.key});

  @override
  State<Market> createState() => _MarketState();
}

class _MarketState extends State<Market> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(alignment: Alignment.bottomCenter, children: [
              Container(
                width: MediaQuery.of(context).size.width,
                height: 600,
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(50),
                        bottomRight: Radius.circular(50))),
                clipBehavior: Clip.hardEdge,
                child: Image.asset(
                  "assets/market/photo2.jpg",
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                  bottom: 20,
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(40, 10, 40, 20),
                    width: MediaQuery.of(context).size.width / 1.1,
                    height: 130,
                    decoration: BoxDecoration(
                        color: eptLightOrange,
                        borderRadius: BorderRadius.circular(30)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Nouvelle Collection",
                          style: TextStyle(
                              fontFamily: "League Gothic",
                              fontWeight: FontWeight.w600,
                              fontSize: 30),
                        ),
                        Row(
                          children: [
                            Image.asset(
                              "assets/market/tupperware.png",
                              scale: 5,
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            const Text(
                              "4 pièces",
                              style:
                                  TextStyle(fontFamily: "Inter", fontSize: 12),
                            ),
                            const SizedBox(
                              width: 40,
                            ),
                            Image.asset(
                              "assets/market/revendeur.png",
                              scale: 5,
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            const Text(
                              "BDE",
                              style:
                                  TextStyle(fontFamily: "Inter", fontSize: 12),
                            )
                          ],
                        ),
                        const Spacer(),
                        Center(
                            child: EptButton(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const Collection(
                                      title: "Blousons 2024",
                                      subtitle: "Classe Polytechnicienne",
                                    )));
                          },
                          title: "Voir tout",
                          width: MediaQuery.of(context).size.width / 1.3,
                          height: 30,
                          color: Colors.black,
                          icon: Image.asset(
                            "assets/market/jouer.png",
                            scale: 7,
                          ),
                          borderRadius: 5,
                        ))
                      ],
                    ),
                  ))
            ]),
            const SizedBox(
              height: 20,
            ),
            const Text(
              "Boutique-Polytech",
              style: TextStyle(
                  fontFamily: "Inter",
                  fontSize: 18,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(
              height: 20,
            ),
            const BoutiqueWrap(),
            const SizedBox(
              height: 40,
            ),
          ],
        ),
      ),
    ));
  }
}
