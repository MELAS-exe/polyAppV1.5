import 'package:flutter/material.dart';
import 'package:polyapp/market/boutique_items.dart';

SearchController controller = SearchController();

class BoutiqueWrap extends StatefulWidget {
  const BoutiqueWrap({super.key});

  @override
  State<BoutiqueWrap> createState() => _BoutiqueWrapState();
}

class _BoutiqueWrapState extends State<BoutiqueWrap> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
            width: MediaQuery.of(context).size.width,
            child: Wrap(
              runSpacing: 20,
              spacing: 20,
              children: [
                BoutiqueItems(title: "Gourde", price: 5000),
                BoutiqueItems(
                  title: "Gourde",
                  price: 5000,
                  image: Image.asset("assets/market/photo3.jpg", fit: BoxFit.cover,),
                ),
                BoutiqueItems(
                  title: "Gourde",
                  price: 5000,
                  image: Image.asset("assets/market/photo3.jpg", fit: BoxFit.cover,),
                ),
                BoutiqueItems(
                  title: "Gourde",
                  price: 5000,
                  image: Image.asset("assets/market/photo3.jpg", fit: BoxFit.cover,),
                ),
                BoutiqueItems(
                  title: "Gourde",
                  price: 5000,
                  image: Image.asset("assets/market/photo3.jpg", fit: BoxFit.cover,),
                ),
                BoutiqueItems(
                  title: "Gourde",
                  price: 5000,
                  image: Image.asset("assets/market/photo3.jpg", fit: BoxFit.cover,),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
