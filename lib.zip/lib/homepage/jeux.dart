import 'package:flutter/material.dart';
import 'package:polyapp/util/gameTiles.dart';

class JeuxHomepage extends StatelessWidget {
  const JeuxHomepage({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Jeux",
            style: TextStyle(
              fontFamily: "Inter",
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 0, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Trouver des joueurs",
                  style: TextStyle(
                    fontFamily: "Inter",
                    fontSize: 12,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      GameTile(
                        image: Image.asset(
                          "assets/Homepage/images.jpg",
                          fit: BoxFit.cover,
                        ),
                        title: "Loup-Garou",
                        widget: Container(),
                        playerCount: 4,
                      ),
                      GameTile(
                        image: Image.asset(
                          "assets/Homepage/24ddccc1a1913173ff58a21e435250ad.jpg",
                          fit: BoxFit.cover,
                        ),
                        title: "UNO",
                        widget: Container(),
                        playerCount: 4,
                      ),
                      GameTile(
                        image: Image.asset(
                          "assets/Homepage/images.png",
                          fit: BoxFit.cover,
                        ),
                        title: "Monopoly",
                        widget: Container(),
                        playerCount: 4,
                      ),
                      GameTile(
                        image: Image.asset(
                          "assets/Homepage/scrabble_color_game_logo_sticker__36846.jpg",
                          fit: BoxFit.cover,
                        ),
                        title: "Scrabble",
                        widget: Container(),
                        playerCount: 4,
                      ),
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
