import 'package:flutter/material.dart';

class EptBackButton extends StatelessWidget {
  const EptBackButton({super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){Navigator.pop(context);},
      child: Image.asset("assets/icons8-flèche-gauche-90.png", scale: 3,),
    );
  }
}