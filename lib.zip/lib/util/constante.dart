import 'package:flutter/material.dart';

const Color eptOrange = Color.fromARGB(255, 244, 171, 90);
const Color eptDarkGrey = Color.fromARGB(255, 119, 119, 119);
const Color etpGrey = Color.fromARGB(255, 217, 217, 217);
const Color eptLightOrange = Color.fromARGB(255, 255, 222, 173);
const Color eptLightGrey = Color.fromARGB(255,217,217,217);
const Color eptLighterOrange = Color.fromARGB(255, 250, 242, 230);
const Color eptLogoOrange = Color.fromARGB(255, 249, 209, 174); 
const Color adeptPurple = Color.fromARGB(255, 75, 0, 82);
const Color adeptYellow = Color.fromARGB(255, 253, 238, 183);