import 'package:flutter/material.dart';
import 'package:polyapp/util/constante.dart';

class GameTile extends StatefulWidget {
  final Image image;
  final String title;
  final Widget widget;
  int playerCount;

  GameTile({
    super.key,
    required this.image,
    required this.title,
    required this.widget,
    this.playerCount = 0,
    });

  @override
  State<GameTile> createState() => _GameTileState();
}

class _GameTileState extends State<GameTile> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 0, 20, 0),
      child: Column(
        children: [
          Text(
            widget.title,
            style: TextStyle(
              fontFamily: "inter",
              fontSize: 10, 
            ),
          ),
          SizedBox(height: 5,),
          Container(
            padding: const EdgeInsets.all(3),
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: etpGrey
            ),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20)
              ),
              clipBehavior: Clip.hardEdge,
              child: widget.image,
            ),
          ),
          SizedBox(height: 5,),
            Text(
            "${widget.playerCount} joeurs en cours",
            style: TextStyle(
              fontFamily: "Inter",
              fontSize: 10, 
            ),
          ),
        ],
      ),
    );
  }
}