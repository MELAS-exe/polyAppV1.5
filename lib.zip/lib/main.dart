import 'package:flutter/material.dart';
import 'package:polyapp/authentification/login.dart';
import 'package:polyapp/homepage/homepage.dart';
import 'package:polyapp/navbar/navbar.dart';
import 'package:polyapp/util/utils.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MaterialApp(debugShowCheckedModeBanner: false, home: Login()));
}
