import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:polyapp/authentification/login.dart';
import 'package:polyapp/util/constante.dart';
import 'package:polyapp/util/login_text_field.dart';

class Register extends StatelessWidget {
  const Register({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Image.asset(
              "assets/connection-inscription/login-background.png",
              fit: BoxFit.cover,
            ),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 10,
                ),
                SvgPicture.asset(
                  "assets/connection-inscription/ept-login-logo.svg",
                  fit: BoxFit.fitHeight,
                  height: 170,
                  color: eptLogoOrange,
                ),
                const SizedBox(
                  height: 10,
                ),
                const Text(
                  "Inscription",
                  style: TextStyle(
                      fontFamily: "Inter",
                      fontSize: 30,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(
                  height: 0,
                ),
                const Text(
                  "Vos premiers pas dans la vie polytechnicienne.",
                  style: TextStyle(
                    fontFamily: "Inter",
                    fontSize: 12,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Center(
                  child: Login_TextField(
                      name: "Nom", inputType: TextInputType.emailAddress),
                ),
                Center(
                  child: Login_TextField(
                      name: "Prenom", inputType: TextInputType.emailAddress),
                ),
                Center(
                  child: Login_TextField(
                      name: "Mail EPT", inputType: TextInputType.emailAddress),
                ),
                Center(
                  child: Login_TextField(
                      name: "Mot de passe",
                      inputType: TextInputType.emailAddress),
                ),
                Center(
                  child: Login_TextField(
                      name: "Confirmer mot de passe",
                      inputType: TextInputType.emailAddress),
                ),
                Center(
                  child: Login_TextField(
                      name: "Promotion", inputType: TextInputType.emailAddress),
                ),
                const SizedBox(
                  height: 30,
                ),
                Center(
                  child: InkWell(
                    onTap: () {},
                    child: Container(
                      width: MediaQuery.of(context).size.width / 1.2,
                      height: 55,
                      decoration: BoxDecoration(
                          color: eptOrange,
                          borderRadius: BorderRadius.circular(40)),
                      child: const Center(
                          child: Text(
                        "S'inscrire",
                        style: TextStyle(
                            fontFamily: "Inter",
                            fontWeight: FontWeight.bold,
                            fontSize: 16),
                      )),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        "Déjà inscris?",
                        style: TextStyle(
                          fontFamily: "Inter",
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) => const Login()));
                        },
                        child: const Text(
                          'Connectez vous!',
                          style: TextStyle(
                              fontFamily: "Inter",
                              color: eptOrange,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              decoration: TextDecoration.underline,
                              decorationColor: eptOrange),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    ));
  }
}
