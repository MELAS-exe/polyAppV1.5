import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:polyapp/authentification/register.dart';
import 'package:polyapp/navbar/navbar.dart';
import 'package:polyapp/util/constante.dart';
import 'package:polyapp/util/login_text_field.dart';

class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Image.asset(
              "assets/connection-inscription/login-background.png",
              fit: BoxFit.cover,
            ),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 30,
                ),
                Center(
                  child: SvgPicture.asset(
                    "assets/connection-inscription/ept-login-logo.svg",
                    fit: BoxFit.fitHeight,
                    height: 330,
                    color: eptLogoOrange,
                  ),
                ),
                const SizedBox(
                  height: 50,
                ),
                const Text(
                  "Connexion",
                  style: TextStyle(
                      fontFamily: "Inter",
                      fontSize: 30,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(
                  height: 0,
                ),
                const Text(
                  "Tous les services des Polytechniciens à portée de main.",
                  style: TextStyle(
                    fontFamily: "Inter",
                    fontSize: 12,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Center(
                  child: Login_TextField(
                      name: "Mail EPT", inputType: TextInputType.emailAddress),
                ),
                Center(
                  child: Login_TextField(
                      name: "Mot de passe",
                      inputType: TextInputType.emailAddress),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const SizedBox(),
                    InkWell(
                      onTap: () {},
                      child: const Text(
                        'Mot de passe oublié?',
                        style: TextStyle(
                            fontFamily: "Inter",
                            color: eptOrange,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                            decoration: TextDecoration.underline,
                            decorationColor: eptOrange),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 70,
                ),
                Center(
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => const NavBar()));
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width / 1.2,
                      height: 55,
                      decoration: BoxDecoration(
                          color: eptOrange,
                          borderRadius: BorderRadius.circular(40)),
                      child: const Center(
                          child: Text(
                        "Se connecter",
                        style: TextStyle(
                            fontFamily: "Inter",
                            fontWeight: FontWeight.bold,
                            fontSize: 16),
                      )),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        "Pas de compte?",
                        style: TextStyle(
                          fontFamily: "Inter",
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) => const Register()));
                        },
                        child: const Text(
                          'Inscrivez vous!',
                          style: TextStyle(
                              fontFamily: "Inter",
                              color: eptOrange,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              decoration: TextDecoration.underline,
                              decorationColor: eptOrange),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    ));
  }
}
